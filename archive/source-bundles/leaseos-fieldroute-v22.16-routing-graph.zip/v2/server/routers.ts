import { randomUUID } from "node:crypto";
import { COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
/**
 * v22.5.1 — the operational truth boundary. Authorization answers "may this
 * person perform this kind of action"; these refusals answer "what may the
 * action establish as fact". A create or capture may carry an observation or
 * a claim; it may not carry a verified, authenticated, resolved, approved or
 * authoritative state, a verification time or verifier, or server provenance.
 * A present value is refused, not silently dropped, so an old client learns.
 */
const REFUSED = z.undefined({ message: "Trust-bearing value refused: this state is established by its own review, verification or transition procedure, never by a create or capture." }).optional();
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { recordsRouter } from "./recordsRouter";
import {
  contractorRouter,
  financeRouter,
  payrollRouter,
} from "./payrollRouter";
import { fundingRouter, portalsRouter } from "./portalFundingRouter";
import { purchasingRouter, recoveryRouter, roadsideRouter, vendorRouter } from "./purchasingRouter";
import { deviceRouter, syncRouter } from "./deviceRouter";
import { complianceRouter } from "./complianceRouter";
import { calibrationRouter, requirementRouter } from "./requirementRouter";
import { surfacesRouter } from "./surfacesRouter";
import { dispatchGateRouter } from "./dispatchRouter";
import { createJobUnitGated } from "./dispatchEnforcementService";
import { iftaRouter } from "./iftaRouter";
import { fuelOpsRouter } from "./fuelOpsRouter";
import { periodRouter } from "./periodRouter";
import { gstRouter } from "./gstRouter";
import { arRouter, bankRouter } from "./cashRouter";
import { commercialRouter, portalAdminRouter } from "./commercialRouter";
import { commercialSetupRouter } from "./commercialSetupRouter";
import { invoicingRouter } from "./invoicingRouter";
import { geoRouter } from "./geoRouter";
import { portalRouter } from "./portalRouter";
import { shopRouter } from "./shopRouter";
import { assetRouter } from "./assetRouter";
import { projectRouter } from "./projectRouter";
import { inboundRouter, integrationRouter } from "./integrationRouter";
import { telematicsRouter } from "./telematicsRouter";
import { workforceRouter } from "./workforceRouter";
import { auditRouter } from "./auditRouter";
import { spatialRouter } from "./spatialRouter";
import { closeoutRouter } from "./closeoutRouter";
import { insuranceRouter } from "./insuranceRouter";
import { publicProcedure, roleProcedure, router } from "./_core/trpc";
import { storagePut } from "./storage";
import {
  createEvidenceRecord,
  findEvidenceByClientCaptureRef,
  createJob,
  createSafetyEvent,
  getJobByCode,
  listEvidenceRecords,
  listJobs,
  listRouteContexts,
  listSafetyEvents,
  verifyEvidenceRecord,
  createRouteContext,
  createComplianceDocument,
  createOperator,
  createUnit,
  createLoadProfile,
  createFacility,
  createMaintenanceDefect,
  createDelivery,
  createSignatureAudit,
  listComplianceDocuments,
  listOperators,
  listUnits,
  listLoadProfiles,
  listFacilities,
  listMaintenanceDefects,
  listDeliveries,
  createJobUnit,
  listJobUnits,
  createInspection,
  listInspections,
  reviewComplianceDocument,
  listLocationIdentities,
  createLocationIdentity,
  listManifests,
  createManifest,
  listScanAudits,
  createScanAudit,
  listComplianceArtifacts,
  createComplianceArtifact,
  listTailgateMeetings,
  createTailgateMeeting,
  listTransferAcknowledgements,
  createTransferAcknowledgement,
  acknowledgeTransfer,
  listBillingRateCards,
  createBillingRateCard,
  listJobChargeLines,
  createJobChargeLine,
  listVendors,
  createVendor,
  listUnitSafetyPlans,
  createUnitSafetyPlan,
  updateBillingRateCard,
  updateVendor,
  updateUnitSafetyPlan,
  listRouteDecisions,
  createRouteDecision,
  listTrips,
  createTrip,
  updateTrip,
  listTripStops,
  createTripStop,
  updateTripStop,
  listOperatingZones,
  createOperatingZone,
  listDutyRecords,
  createDutyRecord,
  listWorkOrders,
  createWorkOrder,
  updateWorkOrder,
  listTripBreadcrumbs,
  listZoneEvents,
  updateZoneEvent,
 getDb } from "./db";
import { ingestBreadcrumb } from "./_core/tripGps";
import { routingSourceStatus } from "./_core/routingSource";
import { operators as operatorsTable, trips as tripsTable } from "../drizzle/schema";
import { and as andOp, eq as eqOp, inArray as inArrayOp } from "drizzle-orm";

/** The session's operator record, or null. Identity is resolved, never named by the request. */
async function operatorForUser(userId: number) {
  const db = await getDb();
  if (!db) return null;
  return (await db.select({ id: operatorsTable.id }).from(operatorsTable).where(eqOp(operatorsTable.userId, userId)).limit(1))[0] ?? null;
}
/** The operator's one active trip, or null. A breadcrumb binds to this, not to a trip the request names. */
async function activeTripForOperator(operatorId: number) {
  const db = await getDb();
  if (!db) return null;
  return (await db.select({ id: tripsTable.id, unitId: tripsTable.unitId }).from(tripsTable).where(andOp(eqOp(tripsTable.operatorId, operatorId), inArrayOp(tripsTable.status, ["loading", "in_transit", "unloading"]))).limit(1))[0] ?? null;
}
/** A scan's access role is the strongest role the caller holds, in the scan audit's vocabulary. */
function scanRoleOf(roles: readonly string[]): "inspection" | "driver" | "mechanic" | "dispatcher" | "admin" {
  if (roles.includes("management") || roles.includes("controller")) return "admin";
  if (roles.includes("dispatcher")) return "dispatcher";
  if (roles.includes("mechanic") || roles.includes("shop_lead")) return "mechanic";
  if (roles.includes("safety") || roles.includes("auditor")) return "inspection";
  return "driver";
}
import {
  createAssistantProposal,
  updateAssistantProposal,
  getAssistantProposal,
  listPendingProposals,
  replaceProposalFields,
  listProposalFields,
} from "./db";
import {
  FORMS,
  buildProposal,
  answerField,
  setFieldStatus,
  generateReadBack,
  acknowledgeReadBack,
  rejectProposal,
  type Proposal,
  type ProposedField,
} from "./_core/aiProposal";
import {
  buildOutputSchema,
  buildSystemPrompt,
  parseExtraction,
  parseModelJson,
} from "./_core/assistantExtraction";
import { rehydrateProposal } from "./_core/assistantPersistence";
import { executeAssistantCommit } from "./_core/assistantCommitService";
import { invokeLLM } from "./_core/llm";

/** Rebuild the in-memory proposal from its stored rows. */
async function loadProposal(proposalId: string): Promise<Proposal | null> {
  const row = await getAssistantProposal(proposalId);
  if (!row) return null;
  const fieldRows = await listProposalFields(proposalId);
  return rehydrateProposal(row, fieldRows);
}

async function persist(p: Proposal) {
  await updateAssistantProposal(p.proposalId, {
    readBack: p.readBack,
    readBackAcknowledged: p.readBackAcknowledged,
    commitState: p.commitState,
  });
  await replaceProposalFields(
    p.proposalId,
    p.fields.map(f => ({
      proposalId: p.proposalId,
      fieldKey: f.key,
      label: f.label,
      fieldValue: JSON.stringify(f.value),
      precision: f.precision,
      source: f.source,
      confidence: f.confidence,
      status: f.status,
      sourceUtterance: f.sourceUtterance ?? null,
      correctedFrom:
        f.correctedFrom === undefined ? null : JSON.stringify(f.correctedFrom),
    }))
  );
}

const jobInput = z.object({
  jobCode: z.string().min(1).max(32),
  type: z.string().min(1).max(120),
  mode: z
    .enum(["general", "hydrovac", "recovery", "transport"])
    .default("general"),
  customer: z.string().min(1).max(160),
  location: z.string().min(1).max(220),
  vehicle: z.string().max(120).optional(),
  driver: z.string().max(120).optional(),
  status: z
    .enum([
      "dispatched",
      "in_transit",
      "loading",
      "on_site",
      "awaiting_docs",
      "complete",
    ])
    .default("dispatched"),
  progress: z.number().int().min(0).max(100).default(0),
  eta: z.string().max(32).optional(),
  latitude: z.number().optional(),
  longitude: z.number().optional(),
});

export const appRouter = router({
  system: systemRouter,
  records: recordsRouter,
  payroll: payrollRouter,
  contractors: contractorRouter,
  finance: financeRouter,
  portals: portalsRouter,
  funding: fundingRouter,
  roadside: roadsideRouter,
  purchasing: purchasingRouter,
  vendor: vendorRouter,
  recovery: recoveryRouter,
  device: deviceRouter,
  sync: syncRouter,
  compliance: complianceRouter,
  requirement: requirementRouter,
  calibration: calibrationRouter,
  surfaces: surfacesRouter,
  dispatch: dispatchGateRouter,
  ifta: iftaRouter,
  fuel: fuelOpsRouter,
  period: periodRouter,
  gst: gstRouter,
  bank: bankRouter,
  ar: arRouter,
  commercial: commercialRouter,
  commercialSetup: commercialSetupRouter,
  invoicing: invoicingRouter,
  geo: geoRouter,
  closeout: closeoutRouter,
  portalAdmin: portalAdminRouter,
  // v21.10 — external identities only; gated by externalProcedure, never by roles.
  portal: portalRouter,
  shop: shopRouter,
  asset: assetRouter,
  project: projectRouter,
  integration: integrationRouter,
  telematics: telematicsRouter,
  workforce: workforceRouter,
  audit: auditRouter,
  spatial: spatialRouter,
  // v21.18 — machines only; gated by integrationProcedure, never by roles.
  inbound: inboundRouter,
  insurance: insuranceRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  fieldRoute: router({
    jobs: router({
      list: roleProcedure("jobs.list").query(() => listJobs()),
      byCode: roleProcedure("jobs.byCode")
        .input(z.object({ jobCode: z.string().min(1) }))
        .query(({ input }) => getJobByCode(input.jobCode)),
      create: roleProcedure("jobs.create")
        .input(jobInput)
        .mutation(({ input }) => createJob(input)),
    }),
    evidence: router({
      list: roleProcedure("evidence.list").query(() => listEvidenceRecords()),
      upload: roleProcedure("evidence.upload")
        .input(
          z.object({
            title: z.string().min(1).max(220),
            category: z.string().min(1).max(80),
            fileName: z.string().min(1).max(220),
            mimeType: z.string().min(1).max(120),
            dataBase64: z.string().min(1),
            latitude: z.number().optional(),
            longitude: z.number().optional(),
            notes: z.string().optional(),
            // v21.6 — offline-first: the device's reference (idempotent) and when it captured.
            clientCaptureRef: z.string().min(8).max(80).optional(),
            capturedAt: z.coerce.date().optional(),
          })
        )
        .mutation(async ({ ctx, input }) => {
          const fileBuffer = Buffer.from(input.dataBase64, "base64");
          if (fileBuffer.byteLength > 15 * 1024 * 1024) {
            throw new TRPCError({
              code: "BAD_REQUEST",
              message: "Evidence files must be 15 MB or smaller.",
            });
          }
          if (input.clientCaptureRef) {
            const existing = await findEvidenceByClientCaptureRef(input.clientCaptureRef);
            if (existing) return { id: existing.id, key: existing.storageKey ?? "", url: existing.storageUrl ?? "", alreadyUploaded: true as const };
          }
          const safeName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-");
          const stored = await storagePut(
            `${ctx.user.id}/evidence/${Date.now()}-${safeName}`,
            fileBuffer,
            input.mimeType
          );
          const id = await createEvidenceRecord({
            title: input.title,
            category: input.category,
            storageKey: stored.key,
            storageUrl: stored.url,
            mimeType: input.mimeType,
            // The device says when it captured; createdAt is when the server received it.
            capturedAt: input.capturedAt ?? new Date(),
            capturedBy: ctx.user.id,
            clientCaptureRef: input.clientCaptureRef ?? null,
            latitude: input.latitude,
            longitude: input.longitude,
            status: "needs_review",
            notes: input.notes,
          });
          return { id, ...stored };
        }),
      add: roleProcedure("evidence.add")
        .input(
          z.object({
            jobId: z.number().int().optional(),
            title: z.string().min(1).max(220),
            category: z.string().min(1).max(80),
            storageKey: z.string().max(512).optional(),
            storageUrl: z.string().max(1024).optional(),
            mimeType: z.string().max(120).optional(),
            capturedAt: z.coerce.date(),
            capturedBy: z.number().int().optional(),
            latitude: z.number().optional(),
            longitude: z.number().optional(),
            status: REFUSED,
            notes: z.string().optional(),
          })
        )
        .mutation(({ input }) => createEvidenceRecord({ ...input, status: "needs_review" })),   // verification is evidence.verify
      verify: roleProcedure("evidence.verify")
        .input(z.object({ id: z.number().int().positive() }))
        .mutation(({ input }) => verifyEvidenceRecord(input.id)),
    }),
    trips: router({
      list: roleProcedure("trips.list").query(() => listTrips()),
      create: roleProcedure("trips.create")
        .input(
          z.object({
            tripNumber: z.string().min(1).max(50),
            jobId: z.number().int().optional(),
            unitId: z.number().int().optional(),
            operatorId: z.number().int().optional(),
            manifestId: z.number().int().optional(),
            originLocationId: z.number().int().optional(),
            destinationFacilityId: z.number().int().optional(),
            tripType: z
              .enum(["round_trip", "one_way", "shuttle"])
              .default("round_trip"),
            status: z
              .enum([
                "planned",
                "loading",
                "in_transit",
                "unloading",
                "complete",
                "cancelled",
              ])
              .default("planned"),
            startedAt: z.coerce.date().optional(),
            completedAt: z.coerce.date().optional(),
            odometerStartKm: z.number().nonnegative().optional(),
            odometerEndKm: z.number().nonnegative().optional(),
            distanceKm: z.number().nonnegative().optional(),
            notes: z.string().optional(),
          })
        )
        .mutation(({ input }) =>
          createTrip({
            ...input,
            distanceKm:
              input.distanceKm ??
              (input.odometerStartKm !== undefined &&
              input.odometerEndKm !== undefined
                ? Math.max(0, input.odometerEndKm - input.odometerStartKm)
                : undefined),
          })
        ),
      update: roleProcedure("trips.update")
        .input(
          z.object({
            id: z.number().int().positive(),
            status: z
              .enum([
                "planned",
                "loading",
                "in_transit",
                "unloading",
                "complete",
                "cancelled",
              ])
              .optional(),
            startedAt: z.coerce.date().optional(),
            completedAt: z.coerce.date().optional(),
            odometerEndKm: z.number().nonnegative().optional(),
            distanceKm: z.number().nonnegative().optional(),
            notes: z.string().optional(),
          })
        )
        .mutation(({ input }) => {
          const { id, ...values } = input;
          return updateTrip(id, values);
        }),
    }),
    tripStops: router({
      list: roleProcedure("tripStops.list")
        .input(z.object({ tripId: z.number().int().optional() }).optional())
        .query(({ input }) => listTripStops(input?.tripId)),
      create: roleProcedure("tripStops.create")
        .input(
          z.object({
            tripId: z.number().int(),
            stopType: z.enum(["load", "unload", "fuel", "checkpoint"]),
            locationId: z.number().int().optional(),
            facilityId: z.number().int().optional(),
            sequence: z.number().int().positive().default(1),
            arrivedAt: z.coerce.date().optional(),
            setupStartedAt: z.coerce.date().optional(),
            operationStartedAt: z.coerce.date().optional(),
            operationCompletedAt: z.coerce.date().optional(),
            departedAt: z.coerce.date().optional(),
            durationMinutes: z.number().nonnegative().optional(),
            setupMinutes: z.number().nonnegative().optional(),
            waitMinutes: z.number().nonnegative().optional(),
            quantity: z.number().nonnegative().optional(),
            quantityUnit: z.string().max(30).optional(),
            ticketNumber: z.string().max(100).optional(),
            notes: z.string().optional(),
          })
        )
        .mutation(({ input }) => {
          const minutes = (a?: Date, b?: Date) =>
            a && b
              ? Math.max(0, (b.getTime() - a.getTime()) / 60000)
              : undefined;
          return createTripStop({
            ...input,
            waitMinutes:
              input.waitMinutes ??
              minutes(input.arrivedAt, input.setupStartedAt),
            setupMinutes:
              input.setupMinutes ??
              minutes(input.setupStartedAt, input.operationStartedAt),
            durationMinutes:
              input.durationMinutes ??
              minutes(input.arrivedAt, input.departedAt),
          });
        }),
      update: roleProcedure("tripStops.update")
        .input(
          z.object({
            id: z.number().int().positive(),
            arrivedAt: z.coerce.date().optional(),
            setupStartedAt: z.coerce.date().optional(),
            operationStartedAt: z.coerce.date().optional(),
            operationCompletedAt: z.coerce.date().optional(),
            departedAt: z.coerce.date().optional(),
            durationMinutes: z.number().nonnegative().optional(),
            setupMinutes: z.number().nonnegative().optional(),
            waitMinutes: z.number().nonnegative().optional(),
            quantity: z.number().nonnegative().optional(),
            ticketNumber: z.string().max(100).optional(),
            notes: z.string().optional(),
          })
        )
        .mutation(({ input }) => {
          const { id, ...values } = input;
          return updateTripStop(id, values);
        }),
    }),
    operatingZones: router({
      list: roleProcedure("operatingZones.list").query(() => listOperatingZones()),
      create: roleProcedure("operatingZones.create")
        .input(
          z.object({
            name: z.string().min(1).max(180),
            zoneType: z.enum(["loading", "unloading", "both"]),
            locationId: z.number().int().optional(),
            facilityId: z.number().int().optional(),
            latitude: z.number(),
            longitude: z.number(),
            radiusMetres: z.number().positive().default(75),
            active: z.number().int().default(1),
            verifiedAt: z.coerce.date().optional(),
            source: z.string().max(220).optional(),
            notes: z.string().optional(),
          })
        )
        .mutation(({ input }) => createOperatingZone(input)),
    }),
    assistant: router({
      forms: roleProcedure("assistant.forms").query(() =>
        Object.values(FORMS).map(f => ({
          key: f.key,
          version: f.version,
          title: f.title,
        }))
      ),

      /**
       * Speech or text in, typed proposal out. The model is constrained by
       * outputSchema to the declared slots — it cannot return a field this
       * form does not have.
       */
      draft: roleProcedure("assistant.draft")
        .input(
          z.object({
            formKey: z.string(),
            targetRef: z.string().max(180),
            transcript: z.string().min(1).max(8000),
            // Structured write context. targetRef remains display-only.
            targetRecordId: z.number().int().positive().optional(),
            eventDateLocal: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
            utcOffsetMinutes: z.number().int().min(-840).max(840).optional(),
            tripId: z.number().int().optional(),
            jobId: z.number().int().optional(),
            unitId: z.number().int().optional(),
            capturedOffline: z.boolean().default(false),
          })
        )
        .mutation(async ({ ctx, input }) => {
          const form = FORMS[input.formKey];
          if (!form) throw new Error(`Unknown form: ${input.formKey}`);

          const result = await invokeLLM({
            messages: [
              {
                role: "system",
                content: buildSystemPrompt(form, input.targetRef),
              },
              { role: "user", content: input.transcript },
            ],
            outputSchema: buildOutputSchema(form),
          });

          // Response is OpenAI-shaped; content may be a string or content parts.
          const raw = result.choices?.[0]?.message?.content ?? "";
          const parsed = parseModelJson(
            typeof raw === "string" ? raw : JSON.stringify(raw)
          );
          const extraction = parseExtraction(form, parsed ?? {});
          const proposal = buildProposal(
            form,
            input.targetRef,
            extraction.values,
            `P-${randomUUID()}`
          );

          await createAssistantProposal({
            proposalId: proposal.proposalId,
            formKey: form.key,
            formVersion: form.version,
            title: form.title,
            targetRef: input.targetRef,
            targetRecordId: input.targetRecordId,
            eventDateLocal: input.eventDateLocal,
            utcOffsetMinutes: input.utcOffsetMinutes,
            jobId: input.jobId,
            tripId: input.tripId,
            unitId: input.unitId,
            createdByUserId: ctx.user.id,
            transcript: input.transcript,
            notes: extraction.notes,
            commitState: proposal.commitState,
            capturedOffline: input.capturedOffline,
            overreachFlags: extraction.overreach.length
              ? JSON.stringify(extraction.overreach)
              : null,
          });
          await persist(proposal);

          return {
            proposal,
            notes: extraction.notes,
            // Surfaced rather than hidden: a model that concluded something is
            // worth a person seeing.
            overreachDetected: extraction.overreach.length > 0,
          };
        }),

      get: roleProcedure("assistant.get")
        .input(z.object({ proposalId: z.string() }))
        .query(({ input }) => loadProposal(input.proposalId)),

      pending: roleProcedure("assistant.pending")
        .input(z.object({ tripId: z.number().int().optional() }).optional())
        .query(({ input }) => listPendingProposals(input?.tripId)),

      answer: roleProcedure("assistant.answer")
        .input(
          z.object({
            proposalId: z.string(),
            fieldKey: z.string(),
            value: z.union([z.string(), z.number(), z.boolean(), z.null()]),
            precision: z.enum(["exact", "approximate"]).default("exact"),
          })
        )
        .mutation(async ({ input }) => {
          const p = await loadProposal(input.proposalId);
          if (!p) throw new Error("Proposal not found");
          const next = answerField(
            p,
            FORMS[p.formKey],
            input.fieldKey,
            input.value,
            input.precision
          );
          await persist(next);
          return next;
        }),

      setStatus: roleProcedure("assistant.setStatus")
        .input(
          z.object({
            proposalId: z.string(),
            fieldKey: z.string(),
            status: z.enum(["proposed", "confirmed", "rejected", "corrected"]),
          })
        )
        .mutation(async ({ input }) => {
          const p = await loadProposal(input.proposalId);
          if (!p) throw new Error("Proposal not found");
          const next = setFieldStatus(
            p,
            FORMS[p.formKey],
            input.fieldKey,
            input.status
          );
          await persist(next);
          return next;
        }),

      readBack: roleProcedure("assistant.readBack")
        .input(z.object({ proposalId: z.string() }))
        .mutation(async ({ input }) => {
          const p = await loadProposal(input.proposalId);
          if (!p) throw new Error("Proposal not found");
          const next = generateReadBack(p);
          await persist(next);
          return next;
        }),

      acknowledge: roleProcedure("assistant.acknowledge")
        .input(z.object({ proposalId: z.string() }))
        .mutation(async ({ input }) => {
          const p = await loadProposal(input.proposalId);
          if (!p) throw new Error("Proposal not found");
          const next = acknowledgeReadBack(p);
          await persist(next);
          return next;
        }),

      /**
       * The only path from proposal to operational record. Refuses with the
       * specific outstanding items rather than a generic failure.
       */
      commit: roleProcedure("assistant.commit")
        .input(z.object({ proposalId: z.string() }))
        .mutation(({ ctx, input }) =>
          executeAssistantCommit({
            proposalId: input.proposalId,
            actorUserId: ctx.user.id,
          })
        ),

      reject: roleProcedure("assistant.reject")
        .input(z.object({ proposalId: z.string() }))
        .mutation(async ({ input }) => {
          const p = await loadProposal(input.proposalId);
          if (!p) throw new Error("Proposal not found");
          await persist(rejectProposal(p));
          return { success: true } as const;
        }),
    }),
    gps: router({
      // Called on an interval (e.g. every 15-30s) or on significant movement
      // while a trip is active. Runs the point against all active operating
      // zones and proposes any enter/exit it implies as a pending zoneEvent —
      // it never writes to tripStops directly.
      submitBreadcrumb: roleProcedure("gps.submitBreadcrumb")
        .input(
          z.object({
            tripId: z.number().int().optional(),
            unitId: REFUSED,
            latitude: z.number().min(-90).max(90),
            longitude: z.number().min(-180).max(180),
            accuracyMetres: z.number().nonnegative().optional(),
            speedKmh: z.number().nonnegative().optional(),
            headingDegrees: z.number().min(0).max(360).optional(),
            source: z.enum(["gps", "dead_reckoning", "manual"]).default("gps"),
            recordedAt: z.coerce.date(),
          })
        )
        .mutation(async ({ ctx, input }) => {
          const own = await operatorForUser(ctx.user.id);
          const active = own ? await activeTripForOperator(own.id) : null;
          if (!active) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "No active trip is assigned to the signed-in operator; a position is not attached to a trip it was not assigned to" });
          if (input.tripId != null && input.tripId !== active.id) throw new TRPCError({ code: "FORBIDDEN", message: `The signed-in operator's active trip is ${active.id}; a breadcrumb is not attached to another trip` });
          return ingestBreadcrumb({ ...input, tripId: active.id, unitId: active.unitId ?? undefined });
        }),
      breadcrumbs: roleProcedure("gps.breadcrumbs")
        .input(z.object({ tripId: z.number().int() }))
        .query(({ input }) => listTripBreadcrumbs(input.tripId)),
      // Pending proposals a driver/dispatcher hasn't ruled on yet. Omit tripId
      // to review pending events across all active trips (dispatch view).
      pendingZoneEvents: roleProcedure("gps.pendingZoneEvents")
        .input(z.object({ tripId: z.number().int().optional() }).optional())
        .query(({ input }) => listZoneEvents(input?.tripId, "pending")),
      zoneEvents: roleProcedure("gps.zoneEvents")
        .input(z.object({ tripId: z.number().int().optional() }).optional())
        .query(({ input }) => listZoneEvents(input?.tripId)),
      // The human-in-the-loop step: a confirmed event can optionally be linked
      // to the tripStop it resolves (e.g. sets arrivedAt). Rejecting it leaves
      // the tripStop entirely untouched — the GPS engine never overwrites a
      // record on its own say-so.
      confirmZoneEvent: roleProcedure("gps.confirmZoneEvent")
        .input(
          z.object({
            id: z.number().int().positive(),
            action: z.enum(["confirm", "reject"]),
            tripStopId: z.number().int().optional(),
          })
        )
        .mutation(async ({ ctx, input }) => {
          await updateZoneEvent(input.id, {
            status: input.action === "confirm" ? "confirmed" : "rejected",
            confirmedAt: new Date(),
            confirmedBy: ctx.user.id,
            tripStopId:
              input.action === "confirm" ? input.tripStopId : undefined,
          });
          return { success: true } as const;
        }),
    }),
    dutyRecords: router({
      list: roleProcedure("dutyRecords.list")
        .input(z.object({ operatorId: z.number().int().optional() }).optional())
        .query(({ input }) => listDutyRecords(input?.operatorId)),
      create: roleProcedure("dutyRecords.create")
        .input(
          z.object({
            operatorId: z.number().int().optional(),
            tripId: z.number().int().optional(),
            dutyStatus: z.enum([
              "driving",
              "on_duty",
              "sleeper_berth",
              "off_duty",
            ]),
            startedAt: z.coerce.date(),
            endedAt: z.coerce.date().optional(),
            durationMinutes: z.number().nonnegative().optional(),
            latitude: z.number().optional(),
            longitude: z.number().optional(),
            locationLabel: z.string().max(220).optional(),
            jurisdiction: z.string().max(100).optional(),
            source: z.string().max(80).default("driver_entry"),
            notes: z.string().optional(),
          })
        )
        .mutation(async ({ ctx, input }) => {
          const own = await operatorForUser(ctx.user.id);
          const roles = (ctx as unknown as { roles?: readonly string[] }).roles ?? [];
          const amending = input.operatorId != null && input.operatorId !== own?.id;
          if (amending && !roles.some(r => r === "dispatcher" || r === "hr" || r === "management")) throw new TRPCError({ code: "FORBIDDEN", message: "A duty record names the operator of the signed-in driver; recording for another operator is an amendment for dispatch, HR or management" });
          const operatorId = amending ? input.operatorId! : own?.id;
          if (operatorId == null) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "No operator record for the signed-in user, and no amendment authority to name one" });
          return createDutyRecord({
            ...input,
            operatorId,
            source: amending ? `amendment by user ${ctx.user.id}` : input.source,
            durationMinutes:
              input.durationMinutes ??
              (input.endedAt
                ? Math.max(
                    0,
                    (input.endedAt.getTime() - input.startedAt.getTime()) /
                      60000
                  )
                : undefined),
          });
        }),
    }),
    workOrders: router({
      list: roleProcedure("workOrders.list")
        .input(z.object({ unitId: z.number().int().optional() }).optional())
        .query(({ input }) => listWorkOrders(input?.unitId)),
      create: roleProcedure("workOrders.create")
        .input(
          z.object({
            workOrderNumber: z.string().min(1).max(80),
            unitId: z.number().int(),
            inspectionId: z.number().int().optional(),
            defectId: z.number().int().optional(),
            status: z
              .enum([
                "draft",
                "open",
                "in_progress",
                "waiting_parts",
                "ready_for_service",
                "closed",
              ])
              .default("open"),
            priority: z
              .enum(["routine", "urgent", "critical"])
              .default("routine"),
            openedAt: z.coerce.date(),
            startedAt: z.coerce.date().optional(),
            completedAt: z.coerce.date().optional(),
            odometerKm: z.number().nonnegative().optional(),
            engineHours: z.number().nonnegative().optional(),
            technician: z.string().max(180).optional(),
            laborMinutes: z.number().nonnegative().optional(),
            parts: z.string().optional(),
            findings: z.string().optional(),
            correctiveAction: z.string().optional(),
          })
        )
        .mutation(({ input }) => createWorkOrder(input)),
      update: roleProcedure("workOrders.update")
        .input(
          z.object({
            id: z.number().int().positive(),
            status: z
              .enum([
                "draft",
                "open",
                "in_progress",
                "waiting_parts",
                "ready_for_service",
                "closed",
              ])
              .optional(),
            priority: z.enum(["routine", "urgent", "critical"]).optional(),
            startedAt: z.coerce.date().optional(),
            completedAt: z.coerce.date().optional(),
            odometerKm: z.number().nonnegative().optional(),
            engineHours: z.number().nonnegative().optional(),
            technician: z.string().max(180).optional(),
            laborMinutes: z.number().nonnegative().optional(),
            parts: z.string().optional(),
            findings: z.string().optional(),
            correctiveAction: z.string().optional(),
          })
        )
        .mutation(({ input }) => {
          const { id, ...values } = input;
          return updateWorkOrder(id, values);
        }),
    }),
    routeContext: router({
      list: roleProcedure("routeContext.list").query(() => listRouteContexts()),
      create: roleProcedure("routeContext.create")
        .input(
          z.object({
            name: z.string().min(1).max(180),
            source: z.string().min(1).max(220),
            effectiveAt: z.coerce.date(),
            expiresAt: z.coerce.date().optional(),
            verifiedAt: REFUSED,
            confidence: REFUSED,
            restrictions: z.string().optional(),
            snapshotKey: z.string().max(512).optional(),
            snapshotUrl: z.string().max(1024).optional(),
          })
        )
        .mutation(({ input }) => createRouteContext({ ...input, verifiedAt: null, confidence: "low", source: `stated: ${input.source}` })),   // a stated source is a claim; verification names its dataset
    }),
    routeDecisions: router({
      list: roleProcedure("routeDecisions.list").query(() => listRouteDecisions()),
      create: roleProcedure("routeDecisions.create")
        .input(
          z.object({
            tripId: z.string().min(1).max(40),
            selectedRoute: z.string().min(1).max(180),
            alternatives: z.string().optional(),
            vehicleType: z.string().min(1).max(100),
            gvwTonnes: z.number().int().positive(),
            axleCount: z.number().int().positive(),
            heightMetres: z.number().int().positive(),
            widthMetres: z.number().int().positive(),
            lengthMetres: z.number().int().positive(),
            hazmatClass: z.string().max(40).optional(),
            quantity: z.string().max(80).optional(),
            riskLevel: z
              .enum(["low", "moderate", "high", "blocked"])
              .default("moderate"),
            source: REFUSED,
            confidence: REFUSED,
            driverAcknowledged: z.number().int().default(0),
          })
        )
        .mutation(({ input }) => createRouteDecision({ ...input, source: `manual choice (routing source ${routingSourceStatus().status})`, confidence: "manual — not authority data" })),   // a person's choice, labelled as one; never authority
    }),
    billing: router({
      rateCards: router({
        list: roleProcedure("rateCards.list").query(() => listBillingRateCards()),
        create: roleProcedure("rateCards.create")
          .input(
            z.object({
              name: z.string().min(1).max(160),
              unitType: z.string().min(1).max(100),
              hourlyRate: z.number().int().nonnegative().default(0),
              dailyRate: z.number().int().nonnegative().default(0),
              jumpHourRate: z.number().int().nonnegative().default(0),
              disposalRate: z.number().int().nonnegative().default(0),
              specialtyEquipmentRate: z.number().int().nonnegative().default(0),
              currency: z.string().length(3).default("CAD"),
              active: z.number().int().default(1),
            })
          )
          .mutation(({ input }) => createBillingRateCard(input)),
        update: roleProcedure("rateCards.update")
          .input(
            z.object({
              id: z.number().int().positive(),
              hourlyRate: z.number().int().nonnegative().optional(),
              dailyRate: z.number().int().nonnegative().optional(),
              jumpHourRate: z.number().int().nonnegative().optional(),
              disposalRate: z.number().int().nonnegative().optional(),
              specialtyEquipmentRate: z.number().int().nonnegative().optional(),
            })
          )
          .mutation(({ input }) => {
            const { id, ...values } = input;
            return updateBillingRateCard(id, values);
          }),
      }),
      lines: router({
        list: roleProcedure("lines.list")
          .input(z.object({ jobId: z.number().int().optional() }).optional())
          .query(({ input }) => listJobChargeLines(input?.jobId)),
        create: roleProcedure("lines.create")
          .input(
            z.object({
              jobId: z.number().int().optional(),
              description: z.string().min(1).max(220),
              quantity: z.number().int().positive(),
              unitRate: z.number().int().nonnegative(),
              source: z.string().max(80).default("rate_card"),
            })
          )
          .mutation(({ input }) =>
            createJobChargeLine({
              ...input,
              amount: input.quantity * input.unitRate,
            })
          ),
      }),
    }),
    vendors: router({
      list: roleProcedure("vendors.list").query(() => listVendors()),
      update: roleProcedure("vendors.update")
        .input(
          z.object({
            id: z.number().int().positive(),
            phone: z.string().max(40).optional(),
            emergencyPhone: z.string().max(40).optional(),
            availability: z.string().max(100).optional(),
            notes: z.string().optional(),
          })
        )
        .mutation(({ input }) => {
          const { id, ...values } = input;
          return updateVendor(id, values);
        }),
      create: roleProcedure("vendors.create")
        .input(
          z.object({
            name: z.string().min(1).max(180),
            category: z.string().min(1).max(100),
            contactName: z.string().max(160).optional(),
            phone: z.string().max(40).optional(),
            emergencyPhone: z.string().max(40).optional(),
            email: z.string().email().optional(),
            coverageArea: z.string().max(220).optional(),
            availability: z.string().max(100).optional(),
            notes: z.string().optional(),
          })
        )
        .mutation(({ input }) => createVendor(input)),
    }),
    unitSafety: router({
      list: roleProcedure("unitSafety.list").query(() => listUnitSafetyPlans()),
      update: roleProcedure("unitSafety.update")
        .input(
          z.object({
            id: z.number().int().positive(),
            hazardSummary: z.string().optional(),
            shutdownProcedure: z.string().optional(),
            requiredPpe: z.string().optional(),
            sdsReferences: z.string().optional(),
            emergencyContacts: z.string().optional(),
            version: z.number().int().optional(),
          })
        )
        .mutation(({ input }) => {
          const { id, ...values } = input;
          return updateUnitSafetyPlan(id, values);
        }),
      create: roleProcedure("unitSafety.create")
        .input(
          z.object({
            unitId: z.number().int().optional(),
            unitLabel: z.string().min(1).max(120),
            hazardSummary: z.string().optional(),
            shutdownProcedure: z.string().optional(),
            requiredPpe: z.string().optional(),
            sdsReferences: z.string().optional(),
            emergencyContacts: z.string().optional(),
            version: z.number().int().default(1),
          })
        )
        .mutation(({ input }) => createUnitSafetyPlan(input)),
    }),
    complianceEngine: router({
      artifacts: router({
        list: roleProcedure("artifacts.list").query(() => listComplianceArtifacts()),
        create: roleProcedure("artifacts.create")
          .input(
            z.object({
              trackingNumber: z.string().min(1).max(40),
              artifactType: z.string().min(1).max(40),
              jobId: z.number().int().optional(),
              locationId: z.number().int().optional(),
              manifestId: z.number().int().optional(),
              status: z
                .enum(["active", "completed", "archived", "legal_hold"])
                .default("active"),
              jurisdiction: z.string().max(100).optional(),
              regulatoryProfile: z.string().max(180).optional(),
              regulatoryVersion: z.string().max(100).optional(),
              retentionUntil: z.coerce.date().optional(),
              metadata: z.string().optional(),
            })
          )
          .mutation(({ input }) => createComplianceArtifact(input)),
      }),
      tailgates: router({
        list: roleProcedure("tailgates.list").query(() => listTailgateMeetings()),
        create: roleProcedure("tailgates.create")
          .input(
            z.object({
              trackingNumber: z.string().min(1).max(40),
              jobId: z.number().int().optional(),
              locationId: z.number().int().optional(),
              supervisor: z.string().max(180).optional(),
              operators: z.string().optional(),
              units: z.string().optional(),
              hazards: z.string().optional(),
              ppe: z.string().optional(),
              controls: z.string().optional(),
              voiceTranscript: z.string().optional(),
              reviewStatus: z
                .enum(["needs_review", "approved"])
                .default("needs_review"),
              startedAt: z.coerce.date().optional(),
              endedAt: z.coerce.date().optional(),
            })
          )
          .mutation(({ input }) => createTailgateMeeting(input)),
      }),
      transfers: router({
        list: roleProcedure("transfers.list").query(() => listTransferAcknowledgements()),
        create: roleProcedure("transfers.create")
          .input(
            z.object({
              trackingNumber: z.string().min(1).max(40),
              channel: z.enum(["email", "portal", "api", "download"]),
              recipient: z.string().min(1).max(220),
              deliveryStatus: z
                .enum(["pending", "confirmed", "failed", "opened"])
                .default("pending"),
              messageId: z.string().max(180).optional(),
              attachmentCount: z.number().int().default(0),
              acknowledgedBy: z.string().max(180).optional(),
              acknowledgedAt: z.coerce.date().optional(),
            })
          )
          .mutation(({ input }) => createTransferAcknowledgement(input)),
        acknowledge: roleProcedure("transfers.acknowledge")
          .input(
            z.object({
              id: z.number().int().positive(),
              acknowledgedBy: z.string().min(1).max(180),
            })
          )
          .mutation(({ input }) =>
            acknowledgeTransfer(input.id, input.acknowledgedBy)
          ),
      }),
    }),
    locations: router({
      list: roleProcedure("locations.list").query(() => listLocationIdentities()),
      create: roleProcedure("locations.create")
        .input(
          z.object({
            name: z.string().min(1).max(180),
            surfaceLsd: z.string().min(1).max(80),
            downholeLsd: z.string().max(80).optional(),
            uwi: z.string().max(120).optional(),
            wellLicense: z.string().max(100).optional(),
            operator: z.string().max(180).optional(),
            lease: z.string().max(180).optional(),
            field: z.string().max(160).optional(),
            province: z.string().max(100).optional(),
            accessRoad: z.string().max(220).optional(),
            gate: z.string().max(180).optional(),
            hazards: z.string().optional(),
            emergencyInfo: z.string().optional(),
            surfaceLatitude: z.number().optional(),
            surfaceLongitude: z.number().optional(),
            downholeLatitude: z.number().optional(),
            downholeLongitude: z.number().optional(),
            source: z.string().max(220).optional(),
            lastVerifiedAt: z.coerce.date().optional(),
          })
        )
        .mutation(({ input }) => createLocationIdentity(input)),
    }),
    manifests: router({
      list: roleProcedure("manifests.list").query(() => listManifests()),
      create: roleProcedure("manifests.create")
        .input(
          z.object({
            manifestNumber: z.string().min(1).max(80),
            locationId: z.number().int().optional(),
            jobId: z.number().int().optional(),
            material: z.string().max(220).optional(),
            unNumber: z.string().max(40).optional(),
            unitId: z.number().int().optional(),
            trailer: z.string().max(100).optional(),
            driver: z.string().max(180).optional(),
            route: z.string().max(220).optional(),
            facility: z.string().max(220).optional(),
            scaleTickets: z.string().optional(),
            evidenceRefs: z.string().optional(),
            signatureRefs: z.string().optional(),
            status: REFUSED,
          })
        )
        .mutation(({ input }) => createManifest({ ...input, status: "draft" })),
    }),
    scans: router({
      list: roleProcedure("scans.list").query(() => listScanAudits()),
      create: roleProcedure("scans.create")
        .input(
          z.object({
            scanType: z.enum(["qr", "nfc"]),
            subjectType: z.enum(["unit", "location", "manifest"]),
            subjectId: z.number().int(),
            accessRole: REFUSED,
            scannedAt: z.coerce.date(),
            latitude: z.number().optional(),
            longitude: z.number().optional(),
          })
        )
        .mutation(({ ctx, input }) => createScanAudit({ ...input, accessRole: scanRoleOf((ctx as unknown as { roles?: readonly string[] }).roles ?? []) })),   // the caller's role, never the caller's claim
    }),
    identity: router({
      operators: router({
        list: roleProcedure("operators.list").query(() => listOperators()),
        create: roleProcedure("operators.create")
          .input(
            z.object({
              userId: z.number().int().optional(),
              name: z.string().min(1).max(180),
              company: z.string().max(180).optional(),
              licenseNumber: z.string().max(100).optional(),
              licenseClass: z.string().max(40).optional(),
              licenseExpiresAt: z.coerce.date().optional(),
              restrictions: z.string().optional(),
              trainingStatus: z.string().max(120).optional(),
              certifications: z.string().optional(),
              insurance: z.string().optional(),
              emergencyContact: z.string().max(220).optional(),
            })
          )
          .mutation(({ input }) => createOperator(input)),
      }),
      units: router({
        list: roleProcedure("units.list").query(() => listUnits()),
        create: roleProcedure("units.create")
          .input(
            z.object({
              unitNumber: z.string().min(1).max(40),
              vin: z.string().max(80).optional(),
              plate: z.string().max(40).optional(),
              vehicleType: z.string().min(1).max(120),
              company: z.string().max(180).optional(),
              weightKg: z.number().int().optional(),
              axles: z.number().int().optional(),
              dimensions: z.string().max(160).optional(),
              equipment: z.string().optional(),
              inspectionStatus: REFUSED,
              maintenanceStatus: REFUSED,
              qrTag: z.string().max(120).optional(),
            })
          )
          .mutation(({ input }) => createUnit({ ...input, inspectionStatus: "due", maintenanceStatus: "review" })),   // a new row proves nothing: due and review until the facts exist
      }),
      jobUnits: router({
        list: roleProcedure("jobUnits.list").query(() => listJobUnits()),
        create: roleProcedure("jobUnits.create")
          .input(
            z.object({
              jobId: z.number().int(),
              unitId: z.number().int(),
              operatorId: z.number().int().optional(),
              role: z.string().min(1).max(100),
              joinedAt: z.coerce.date(),
              departedAt: z.coerce.date().optional(),
              hours: z.number().int().optional(),
              mileage: z.number().int().optional(),
              workPerformed: z.string().optional(),
              // v21.2 — the readiness check this assignment relies on. Required
              // when enforcement is on; recorded whenever supplied.
              eligibilityCheckId: z.number().int().positive().nullable().optional(),
            })
          )
          // v21.2 — under the enforcement setting: off as always, advisory
          // records findings, enforced refuses without a valid check.
          .mutation(async ({ input }) => { const r = await createJobUnitGated(input); return r.id; }),
      }),
      inspections: router({
        list: roleProcedure("inspections.list").query(() => listInspections()),
        create: roleProcedure("inspections.create")
          .input(
            z.object({
              unitId: z.number().int(),
              type: z.enum(["training", "pre_trip", "post_trip"]),
              status: z
                .enum(["pass", "fail", "needs_maintenance", "not_applicable"])
                .default("pass"),
              checklist: z.string().optional(),
              resultSummary: z.string().optional(),
              observedAt: z.coerce.date(),
              authenticatedOperatorId: z.number().int().optional(),
            })
          )
          .mutation(({ input }) => createInspection(input)),
      }),
      documents: router({
        list: roleProcedure("documents.list").query(() => listComplianceDocuments()),
        create: roleProcedure("documents.create")
          .input(
            z.object({
              ownerType: z.enum(["operator", "unit", "job"]),
              ownerId: z.number().int(),
              docType: z.string().min(1).max(100),
              title: z.string().min(1).max(220),
              storageKey: z.string().max(512).optional(),
              storageUrl: z.string().max(1024).optional(),
              capturedAt: z.coerce.date(),
              expiresAt: z.coerce.date().optional(),
              verificationStatus: REFUSED,
              source: z.string().max(220).optional(),
              confidence: z.enum(["low", "medium", "high"]).default("medium"),
            })
          )
          .mutation(({ input }) => createComplianceDocument({ ...input, verificationStatus: "needs_review" })),   // review is documents.review
        review: roleProcedure("documents.review")
          .input(
            z.object({
              id: z.number().int().positive(),
              status: z.enum(["verified", "rejected"]),
            })
          )
          .mutation(({ input }) =>
            reviewComplianceDocument(input.id, input.status)
          ),
      }),
    }),
    compliance: router({
      loads: router({
        list: roleProcedure("loads.list").query(() => listLoadProfiles()),
        create: roleProcedure("loads.create")
          .input(
            z.object({
              jobId: z.number().int(),
              material: z.string().min(1).max(220),
              isWaste: z.boolean().default(false),
              composition: z.string().optional(),
              sdsStorageKey: z.string().max(512).optional(),
              sdsStorageUrl: z.string().max(1024).optional(),
              unNumber: z.string().max(40).optional(),
              properShippingName: z.string().max(220).optional(),
              dgClass: z.string().max(40).optional(),
              packingGroup: z.string().max(40).optional(),
              quantity: z.string().max(80).optional(),
              transportMode: z.string().max(80).optional(),
              jurisdiction: z.string().max(120).optional(),
              classificationStatus: REFUSED,
              source: z.string().max(220).optional(),
              confidence: z.enum(["low", "medium", "high"]).default("low"),
              verifiedAt: REFUSED,
            })
          )
          .mutation(({ input }) => createLoadProfile({ ...input, classificationStatus: "needs_verification", verifiedAt: null })),   // TDG is never self-certified
      }),
      facilities: router({
        list: roleProcedure("facilities.list").query(() => listFacilities()),
        create: roleProcedure("facilities.create")
          .input(
            z.object({
              name: z.string().min(1).max(220),
              status: z.enum(["unknown", "open", "closed"]).default("unknown"),
              operatingHours: z.string().max(120).optional(),
              acceptedMaterials: z.string().optional(),
              restrictions: z.string().optional(),
              phone: z.string().max(60).optional(),
              emergencyPhone: z.string().max(60).optional(),
              gateInstructions: z.string().optional(),
              requiredDocuments: z.string().optional(),
              lastVerifiedAt: z.coerce.date().optional(),
              latitude: z.number().optional(),
              longitude: z.number().optional(),
            })
          )
          .mutation(({ input }) => createFacility(input)),
      }),
      maintenance: router({
        list: roleProcedure("maintenance.list").query(() => listMaintenanceDefects()),
        create: roleProcedure("maintenance.create")
          .input(
            z.object({
              unitId: z.number().int(),
              title: z.string().min(1).max(220),
              severity: z
                .enum(["advisory", "inspection_required", "critical"])
                .default("advisory"),
              status: REFUSED,
              detail: z.string().optional(),
              storageKey: z.string().max(512).optional(),
              storageUrl: z.string().max(1024).optional(),
              reportedAt: z.coerce.date(),
              reportedBy: z.number().int().optional(),
              workOrderNumber: z.string().max(80).optional(),
              completedAt: z.coerce.date().optional(),
            })
          )
          .mutation(({ input }) => createMaintenanceDefect({ ...input, status: "open" })),   // resolution is a later act
      }),
      deliveries: router({
        list: roleProcedure("deliveries.list").query(() => listDeliveries()),
        create: roleProcedure("deliveries.create")
          .input(
            z.object({
              jobId: z.number().int(),
              recipientRole: z.string().min(1).max(80),
              recipient: z.string().min(1).max(220),
              status: z
                .enum(["queued", "delivered", "failed"])
                .default("queued"),
              deliveredAt: z.coerce.date().optional(),
            })
          )
          .mutation(({ input }) => createDelivery(input)),
      }),
      sign: roleProcedure("compliance.sign")
        .input(
          z.object({
            jobId: z.number().int(),
            signerName: z.string().min(1).max(180),
            authMethod: REFUSED,
            signedAt: z.coerce.date(),
            documentHash: REFUSED,
            status: REFUSED,
          })
        )
        .mutation(({ input }) => createSignatureAudit({ ...input, authMethod: "legacy observation — not the frozen signature chain (use closeout.siteSign)", documentHash: null, status: "pending" })),
    }),
    safety: router({
      list: roleProcedure("safety.list").query(() => listSafetyEvents()),
      create: roleProcedure("safety.create")
        .input(
          z.object({
            jobId: z.number().int().optional(),
            eventType: z.string().min(1).max(80),
            severity: z.enum(["info", "warning", "critical"]).default("info"),
            title: z.string().min(1).max(220),
            detail: z.string().optional(),
            occurredAt: z.coerce.date(),
            status: REFUSED,
          })
        )
        .mutation(({ input }) => createSafetyEvent({ ...input, status: "open" })),
    }),
  }),
});

export type AppRouter = typeof appRouter;
