/**
 * Universal surfaces — the service.
 *
 * Reads the exception-bearing tables into the snapshot the engine derives
 * from; assembles the inbox from the two existing task/notification tables
 * plus what awaits the caller; resolves tracking numbers across entities;
 * and walks an entity's history into a timeline. Nothing here is a new store.
 */

import { and, desc, eq, gte, inArray, isNull, like, lte, or, sql } from "drizzle-orm";
import { getDb } from "./db";
import {
  assistantCommitReceipts, assistantProposals, assistantQuestions, calibrationEvents, carrierProfileReviews,
  complianceDocuments, disposalTickets, fieldDevices, fuelTransactions, insurancePolicies, invoices, jobs, loads,
  maintenanceDefects, measurementDevices, operationalTasks, operators, purchaseAuthorizations, roadsideServiceEvents,
  syncConflicts, syncPackages, trips, units, vendorBills, vendors, workflowNotifications, workOrderReleases, workOrders,
} from "../drizzle/schema";
import { calibrationStatus, type CalibrationEvent } from "./_core/requirementEngine";
import type { ExceptionSources } from "./_core/exceptionCentre";
import { loadUngatedAssignments } from "./dispatchEnforcementService";
import { loadFuelLineFindings } from "./periodCloseService";

const DAY = 86_400_000;

/* ------------------------------------------------------------------ */
/* Exception sources                                                    */
/* ------------------------------------------------------------------ */

export async function loadExceptionSources(now = new Date()): Promise<ExceptionSources> {
  const db = await getDb();
  const empty: ExceptionSources = {
    now, criticalDefects: [], roadsideOpen: [], vendorBills: [], purchaseRequests: [], credentials: [], aiProposals: [], aiQuestions: [],
    syncConflicts: [], revokedDevicesWithQueue: [], measurementDevices: [], insurancePolicies: [], carrierProfileReviews: [], ungatedAssignments: [], statementsWithFindings: [], tanksOutOfTolerance: [], periodsSoftClosed: [],
  };
  if (!db) return empty;
  const horizon = new Date(now.getTime() + 90 * DAY);

  const [defects, roadside, bills, pas, creds, proposals, questions, conflicts, revoked, devices, policies, reviews] = await Promise.all([
    db.select({ id: maintenanceDefects.id, unitId: maintenanceDefects.unitId, title: maintenanceDefects.title, reportedAt: maintenanceDefects.reportedAt, status: maintenanceDefects.status, unitNumber: units.unitNumber })
      .from(maintenanceDefects).leftJoin(units, eq(units.id, maintenanceDefects.unitId))
      .where(and(eq(maintenanceDefects.severity, "critical"), inArray(maintenanceDefects.status, ["open", "in_progress"]))).limit(500),
    db.select({ id: roadsideServiceEvents.id, eventRef: roadsideServiceEvents.eventRef, eventType: roadsideServiceEvents.eventType, occurredAt: roadsideServiceEvents.occurredAt, assignedVendorId: roadsideServiceEvents.assignedVendorId, unitNumber: units.unitNumber })
      .from(roadsideServiceEvents).leftJoin(units, eq(units.id, roadsideServiceEvents.unitId))
      .where(inArray(roadsideServiceEvents.status, ["open", "vendor_assigned", "in_repair", "repaired_awaiting_release"])).limit(500),
    db.select({ id: vendorBills.id, billRef: vendorBills.billRef, totalCents: vendorBills.totalCents, status: vendorBills.status, matchOutcome: vendorBills.matchOutcome, receivedAt: vendorBills.receivedAt, dueAt: vendorBills.dueAt, vendorName: vendors.name })
      .from(vendorBills).leftJoin(vendors, eq(vendors.id, vendorBills.vendorId))
      .where(inArray(vendorBills.status, ["needs_coding", "needs_approval", "missing_receipt", "mismatch", "duplicate_suspected"])).limit(500),
    db.select().from(purchaseAuthorizations).where(eq(purchaseAuthorizations.status, "requested")).limit(500),
    db.select({ id: complianceDocuments.id, ownerType: complianceDocuments.ownerType, ownerId: complianceDocuments.ownerId, docType: complianceDocuments.docType, title: complianceDocuments.title, expiresAt: complianceDocuments.expiresAt, verificationStatus: complianceDocuments.verificationStatus })
      .from(complianceDocuments)
      .where(or(eq(complianceDocuments.verificationStatus, "needs_review"), and(lte(complianceDocuments.expiresAt, horizon), eq(complianceDocuments.verificationStatus, "verified")))).limit(2000),
    db.select({ proposalId: assistantProposals.proposalId, formKey: assistantProposals.formKey, title: assistantProposals.title, createdAt: assistantProposals.createdAt, commitState: assistantProposals.commitState })
      .from(assistantProposals).where(eq(assistantProposals.commitState, "awaiting_readback")).limit(500),
    db.select({ askedToUserId: assistantQuestions.askedToUserId, count: sql<number>`count(*)`, oldest: sql<Date | null>`min(${assistantQuestions.createdAt})` })
      .from(assistantQuestions).where(eq(assistantQuestions.status, "pending")).groupBy(assistantQuestions.askedToUserId),
    db.select({ id: syncConflicts.id, conflictRef: syncConflicts.conflictRef, recordType: syncConflicts.recordType, recordRef: syncConflicts.recordRef, material: syncConflicts.material, detectedAt: syncConflicts.detectedAt })
      .from(syncConflicts).where(eq(syncConflicts.status, "unresolved")).limit(500),
    db.select({ deviceRef: fieldDevices.deviceRef, userId: fieldDevices.userId, revokedAt: fieldDevices.revokedAt, queued: sql<number>`count(${syncPackages.id})` })
      .from(fieldDevices).innerJoin(syncPackages, and(eq(syncPackages.fieldDeviceId, fieldDevices.id), eq(syncPackages.state, "queued")))
      .where(eq(fieldDevices.status, "revoked")).groupBy(fieldDevices.id),
    db.select().from(measurementDevices).where(inArray(measurementDevices.status, ["active", "out_of_service"])).limit(500),
    db.select({ policyRef: insurancePolicies.policyRef, policyType: insurancePolicies.policyType, expiresAt: insurancePolicies.expiresAt, status: insurancePolicies.status })
      .from(insurancePolicies).where(lte(insurancePolicies.expiresAt, horizon)).limit(500),
    db.select({ reviewRef: carrierProfileReviews.reviewRef, unmatchedExternalEvents: carrierProfileReviews.unmatchedExternalEvents, reviewedAt: carrierProfileReviews.reviewedAt, nextReviewDueAt: carrierProfileReviews.nextReviewDueAt })
      .from(carrierProfileReviews).orderBy(desc(carrierProfileReviews.profileObtainedAt)).limit(50),
  ]);

  // Owner labels for credentials: operator names where the owner is an operator.
  const operatorIds = Array.from(new Set(creds.filter(c => c.ownerType === "operator").map(c => c.ownerId)));
  const opRows = operatorIds.length ? await db.select({ id: operators.id, name: operators.name }).from(operators).where(inArray(operators.id, operatorIds)) : [];
  const opName = new Map(opRows.map(o => [o.id, o.name]));
  const unitIds = Array.from(new Set(creds.filter(c => c.ownerType === "unit").map(c => c.ownerId)));
  const unitRows = unitIds.length ? await db.select({ id: units.id, unitNumber: units.unitNumber }).from(units).where(inArray(units.id, unitIds)) : [];
  const unitNo = new Map(unitRows.map(u => [u.id, u.unitNumber]));

  // Calibration state per device from its events.
  const deviceIds = devices.map(d => d.id);
  const evRows = deviceIds.length ? await db.select().from(calibrationEvents).where(inArray(calibrationEvents.measurementDeviceId, deviceIds)) : [];
  const evByDevice = new Map<number, CalibrationEvent[]>();
  for (const e of evRows) evByDevice.set(e.measurementDeviceId, [...(evByDevice.get(e.measurementDeviceId) ?? []), e as CalibrationEvent]);

  // Only the latest review per company matters for "overdue"; unmatched events on any.
  const latestReviews = new Map<string, (typeof reviews)[number]>();
  for (const r of reviews) if (!latestReviews.has(r.reviewRef)) latestReviews.set(r.reviewRef, r);

  return {
    now,
    criticalDefects: defects.map(d => ({ id: d.id, unitId: d.unitId, unitNumber: d.unitNumber ?? null, title: d.title, reportedAt: d.reportedAt, status: d.status })),
    roadsideOpen: roadside.map(r => ({ id: r.id, eventRef: r.eventRef, unitNumber: r.unitNumber ?? null, eventType: r.eventType, occurredAt: r.occurredAt, vendorAssigned: r.assignedVendorId != null })),
    vendorBills: bills.map(b => ({ id: b.id, billRef: b.billRef, vendorName: b.vendorName ?? null, total: b.totalCents / 100, status: b.status, matchOutcome: b.matchOutcome, receivedAt: b.receivedAt, dueAt: b.dueAt })),
    purchaseRequests: pas.map(p => ({ id: p.id, authorizationRef: p.authorizationRef, estimatedAmount: p.estimatedAmount, emergency: p.emergency, requestedAt: p.requestedAt, expiresAt: p.expiresAt, status: p.status })),
    credentials: creds.map(c => ({ id: c.id, ownerType: c.ownerType, ownerId: c.ownerId, ownerLabel: c.ownerType === "operator" ? opName.get(c.ownerId) ?? null : c.ownerType === "unit" ? (unitNo.get(c.ownerId) ? `Unit ${unitNo.get(c.ownerId)}` : null) : null, docType: c.docType, title: c.title, expiresAt: c.expiresAt, verificationStatus: c.verificationStatus })),
    aiProposals: proposals,
    aiQuestions: questions.map(q => ({ count: Number(q.count), oldest: q.oldest ? new Date(q.oldest) : null, askedToUserId: q.askedToUserId })),
    syncConflicts: conflicts,
    revokedDevicesWithQueue: revoked.map(r => ({ deviceRef: r.deviceRef, userId: r.userId, queued: Number(r.queued), revokedAt: r.revokedAt })),
    measurementDevices: devices.map(d => { const st = calibrationStatus({ events: evByDevice.get(d.id) ?? [], intervalDays: d.calibrationIntervalDays, now }); return { deviceRef: d.deviceRef, deviceType: d.deviceType, status: d.status, calibrationState: st.status, daysRemaining: st.daysRemaining }; }),
    insurancePolicies: policies,
    carrierProfileReviews: Array.from(latestReviews.values()),
    ungatedAssignments: await loadUngatedAssignments(),
    ...(await loadFuelLineFindings()),
  };
}

/* ------------------------------------------------------------------ */
/* Inbox                                                                */
/* ------------------------------------------------------------------ */

export type InboxItem = {
  kind: "task" | "approval" | "notification" | "ai_proposal" | "ai_question" | "conflict" | "my_request";
  ref: string; title: string; detail: string | null; dueAt: Date | null; since: Date; deepLink: { portal: string; route: string };
};

export async function loadInbox(args: { userId: number; roles: readonly string[]; canApprovePurchases: boolean; canResolveConflicts: boolean; canReviewAssistant: boolean }): Promise<InboxItem[]> {
  const db = await getDb();
  if (!db) return [];
  const roles = args.roles.length ? args.roles : ["__none__"];
  const [tasks, notes, myProposals, myQuestions, myRequests] = await Promise.all([
    db.select().from(operationalTasks).where(and(inArray(operationalTasks.status, ["open", "acknowledged", "in_progress"] as never), or(eq(operationalTasks.assignedUserId, args.userId), inArray(operationalTasks.assignedRole, roles)))).limit(200),
    db.select().from(workflowNotifications).where(and(or(eq(workflowNotifications.recipientUserId, args.userId), inArray(workflowNotifications.recipientRole, roles)), isNull(workflowNotifications.acknowledgedAt))).orderBy(desc(workflowNotifications.queuedAt)).limit(100),
    db.select({ proposalId: assistantProposals.proposalId, title: assistantProposals.title, formKey: assistantProposals.formKey, createdAt: assistantProposals.createdAt }).from(assistantProposals).where(and(eq(assistantProposals.createdByUserId, args.userId), eq(assistantProposals.commitState, "awaiting_readback"))).limit(50),
    db.select({ questionRef: assistantQuestions.questionRef, question: assistantQuestions.question, createdAt: assistantQuestions.createdAt }).from(assistantQuestions).where(and(eq(assistantQuestions.askedToUserId, args.userId), eq(assistantQuestions.status, "pending"))).limit(50),
    db.select({ authorizationRef: purchaseAuthorizations.authorizationRef, status: purchaseAuthorizations.status, estimatedAmount: purchaseAuthorizations.estimatedAmount, requestedAt: purchaseAuthorizations.requestedAt }).from(purchaseAuthorizations).where(and(eq(purchaseAuthorizations.requestedByUserId, args.userId), eq(purchaseAuthorizations.status, "requested"))).limit(50),
  ]);
  const items: InboxItem[] = [];
  for (const t of tasks) items.push({ kind: "task", ref: t.taskNumber, title: t.title, detail: t.description ?? null, dueAt: t.dueAt, since: t.createdAt, deepLink: { portal: "office_administration", route: `/tasks/${t.taskNumber}` } });
  for (const n of notes) items.push({ kind: "notification", ref: n.notificationKey, title: n.title, detail: n.body ?? null, dueAt: null, since: n.queuedAt, deepLink: { portal: "office_administration", route: n.deepLink ?? "/inbox" } });
  for (const p of myProposals) items.push({ kind: "ai_proposal", ref: p.proposalId, title: `Confirm your ${p.formKey.replace(/_/g, " ")}: ${p.title}`, detail: "Read-back awaits your confirmation", dueAt: null, since: p.createdAt, deepLink: { portal: "field_workforce", route: `/assistant/proposals/${p.proposalId}` } });
  for (const q of myQuestions) items.push({ kind: "ai_question", ref: q.questionRef, title: q.question, detail: null, dueAt: null, since: q.createdAt, deepLink: { portal: "field_workforce", route: `/assistant/questions/${q.questionRef}` } });
  for (const r of myRequests) items.push({ kind: "my_request", ref: r.authorizationRef, title: `Your purchase request $${r.estimatedAmount.toFixed(2)} is awaiting approval`, detail: null, dueAt: null, since: r.requestedAt, deepLink: { portal: "field_workforce", route: `/purchasing/${r.authorizationRef}` } });
  if (args.canApprovePurchases) {
    const pending = await db.select({ authorizationRef: purchaseAuthorizations.authorizationRef, estimatedAmount: purchaseAuthorizations.estimatedAmount, emergency: purchaseAuthorizations.emergency, requestedAt: purchaseAuthorizations.requestedAt, requestedByUserId: purchaseAuthorizations.requestedByUserId }).from(purchaseAuthorizations).where(eq(purchaseAuthorizations.status, "requested")).limit(50);
    // Never one's own request — that is not an approval one may give.
    for (const p of pending.filter(p => p.requestedByUserId !== args.userId)) items.push({ kind: "approval", ref: p.authorizationRef, title: `${p.emergency ? "Emergency " : ""}purchase approval: $${p.estimatedAmount.toFixed(2)}`, detail: null, dueAt: null, since: p.requestedAt, deepLink: { portal: "management", route: `/purchasing/${p.authorizationRef}` } });
  }
  if (args.canResolveConflicts) {
    const conflicts = await db.select({ conflictRef: syncConflicts.conflictRef, recordType: syncConflicts.recordType, recordRef: syncConflicts.recordRef, detectedAt: syncConflicts.detectedAt }).from(syncConflicts).where(eq(syncConflicts.status, "unresolved")).limit(50);
    for (const c of conflicts) items.push({ kind: "conflict", ref: c.conflictRef, title: `Resolve sync conflict on ${c.recordType} ${c.recordRef}`, detail: null, dueAt: null, since: c.detectedAt, deepLink: { portal: "office_administration", route: `/sync/conflicts/${c.conflictRef}` } });
  }
  return items.sort((a, b) => (a.dueAt?.getTime() ?? Infinity) - (b.dueAt?.getTime() ?? Infinity) || b.since.getTime() - a.since.getTime());
}

/* ------------------------------------------------------------------ */
/* Search                                                               */
/* ------------------------------------------------------------------ */

export type SearchHit = { entityType: string; entityId: number | string; label: string; status: string | null; deepLink: { portal: string; route: string }; readPermission: string };

/** Resolve a tracking number or free text across entities. Permission filtering is the router's job. */
export async function searchEverything(q: string): Promise<SearchHit[]> {
  const db = await getDb();
  if (!db) return [];
  const term = q.trim();
  if (term.length < 2) return [];
  const pat = `%${term}%`;
  const hits: SearchHit[] = [];
  const [u, j, t, l, d, i, wo, pa, vb, rs, fd, md, ip, fx] = await Promise.all([
    db.select({ id: units.id, unitNumber: units.unitNumber, maintenanceStatus: units.maintenanceStatus }).from(units).where(like(units.unitNumber, pat)).limit(10),
    db.select({ id: jobs.id, jobNumber: jobs.jobCode, status: jobs.status, customer: jobs.customer }).from(jobs).where(or(like(jobs.jobCode, pat), like(jobs.customer, pat))).limit(10),
    db.select({ id: trips.id, tripNumber: trips.tripNumber, status: trips.status }).from(trips).where(like(trips.tripNumber, pat)).limit(10),
    db.select({ id: loads.id, loadNumber: loads.loadNumber, chainState: loads.chainState }).from(loads).where(like(loads.loadNumber, pat)).limit(10),
    db.select({ id: disposalTickets.id, ticketNumber: disposalTickets.ticketNumber, facilityTicketNumber: disposalTickets.facilityTicketNumber, verificationStatus: disposalTickets.verificationStatus }).from(disposalTickets).where(or(like(disposalTickets.ticketNumber, pat), like(disposalTickets.facilityTicketNumber, pat))).limit(10),
    db.select({ id: invoices.id, invoiceNumber: invoices.invoiceNumber, status: invoices.status }).from(invoices).where(like(invoices.invoiceNumber, pat)).limit(10),
    db.select({ id: workOrders.id, workOrderNumber: workOrders.workOrderNumber, status: workOrders.status }).from(workOrders).where(like(workOrders.workOrderNumber, pat)).limit(10),
    db.select({ id: purchaseAuthorizations.id, authorizationRef: purchaseAuthorizations.authorizationRef, status: purchaseAuthorizations.status }).from(purchaseAuthorizations).where(like(purchaseAuthorizations.authorizationRef, pat)).limit(10),
    db.select({ id: vendorBills.id, billRef: vendorBills.billRef, vendorInvoiceNumber: vendorBills.vendorInvoiceNumber, status: vendorBills.status }).from(vendorBills).where(or(like(vendorBills.billRef, pat), like(vendorBills.vendorInvoiceNumber, pat))).limit(10),
    db.select({ id: roadsideServiceEvents.id, eventRef: roadsideServiceEvents.eventRef, status: roadsideServiceEvents.status }).from(roadsideServiceEvents).where(like(roadsideServiceEvents.eventRef, pat)).limit(10),
    db.select({ deviceRef: fieldDevices.deviceRef, status: fieldDevices.status }).from(fieldDevices).where(like(fieldDevices.deviceRef, pat)).limit(10),
    db.select({ deviceRef: measurementDevices.deviceRef, status: measurementDevices.status, deviceType: measurementDevices.deviceType }).from(measurementDevices).where(like(measurementDevices.deviceRef, pat)).limit(10),
    db.select({ policyRef: insurancePolicies.policyRef, policyNumber: insurancePolicies.policyNumber, status: insurancePolicies.status }).from(insurancePolicies).where(or(like(insurancePolicies.policyRef, pat), like(insurancePolicies.policyNumber, pat))).limit(10),
    db.select({ id: fuelTransactions.id, fuelRef: fuelTransactions.fuelRef, status: fuelTransactions.status }).from(fuelTransactions).where(like(fuelTransactions.fuelRef, pat)).limit(10),
  ]);
  for (const x of u) hits.push({ entityType: "unit", entityId: x.id, label: `Unit ${x.unitNumber}`, status: x.maintenanceStatus ?? null, deepLink: { portal: "fleet_maintenance", route: `/units/${x.id}` }, readPermission: "roadside.report" }); // every operational role may name a unit; deeper detail is gated on the unit's own routes
  for (const x of j) hits.push({ entityType: "job", entityId: x.id, label: `${x.jobNumber}${x.customer ? ` — ${x.customer}` : ""}`, status: x.status, deepLink: { portal: "dispatch_operations", route: `/jobs/${x.id}` }, readPermission: "job.read" });
  for (const x of t) hits.push({ entityType: "trip", entityId: x.id, label: x.tripNumber, status: x.status, deepLink: { portal: "dispatch_operations", route: `/trips/${x.id}` }, readPermission: "trip.read" });
  for (const x of l) hits.push({ entityType: "load", entityId: x.id, label: x.loadNumber ?? `Load #${x.id}`, status: x.chainState, deepLink: { portal: "dispatch_operations", route: `/loads/${x.id}` }, readPermission: "load.read" });
  for (const x of d) hits.push({ entityType: "disposalTicket", entityId: x.id, label: `${x.ticketNumber}${x.facilityTicketNumber ? ` (facility ${x.facilityTicketNumber})` : ""}`, status: x.verificationStatus, deepLink: { portal: "office_administration", route: `/disposal/${x.id}` }, readPermission: "evidence.read_job_operational" });
  for (const x of i) hits.push({ entityType: "invoice", entityId: x.id, label: x.invoiceNumber, status: x.status, deepLink: { portal: "finance_billing", route: `/invoices/${x.id}` }, readPermission: "billing.read" });
  for (const x of wo) hits.push({ entityType: "workOrder", entityId: x.id, label: x.workOrderNumber, status: x.status, deepLink: { portal: "fleet_maintenance", route: `/work-orders/${x.id}` }, readPermission: "maintenance.read_defect" });
  for (const x of pa) hits.push({ entityType: "purchaseAuthorization", entityId: x.id, label: x.authorizationRef, status: x.status, deepLink: { portal: "management", route: `/purchasing/${x.authorizationRef}` }, readPermission: "purchasing.request" });
  for (const x of vb) hits.push({ entityType: "vendorBill", entityId: x.id, label: `${x.billRef} (${x.vendorInvoiceNumber})`, status: x.status, deepLink: { portal: "finance_billing", route: `/ap/bills/${x.billRef}` }, readPermission: "vendor.bill.review" });
  for (const x of rs) hits.push({ entityType: "roadsideEvent", entityId: x.id, label: x.eventRef, status: x.status, deepLink: { portal: "dispatch_operations", route: `/roadside/${x.eventRef}` }, readPermission: "roadside.report" });
  for (const x of fd) hits.push({ entityType: "fieldDevice", entityId: x.deviceRef, label: x.deviceRef, status: x.status, deepLink: { portal: "safety_compliance", route: `/devices/${x.deviceRef}` }, readPermission: "device.manage" });
  for (const x of md) hits.push({ entityType: "measurementDevice", entityId: x.deviceRef, label: `${x.deviceType.replace(/_/g, " ")} ${x.deviceRef}`, status: x.status, deepLink: { portal: "fleet_maintenance", route: `/calibration/${x.deviceRef}` }, readPermission: "calibration.impact" });
  for (const x of ip) hits.push({ entityType: "insurancePolicy", entityId: x.policyRef, label: `Policy ${x.policyRef} (${x.policyNumber})`, status: x.status, deepLink: { portal: "finance_billing", route: `/insurance/policies/${x.policyRef}` }, readPermission: "insurance.read_summary" });
  for (const x of fx) hits.push({ entityType: "fuelTransaction", entityId: x.id, label: x.fuelRef, status: x.status, deepLink: { portal: "finance_billing", route: `/fuel/${x.id}` }, readPermission: "tax.expense.review" });
  return hits;
}

/* ------------------------------------------------------------------ */
/* Timeline                                                             */
/* ------------------------------------------------------------------ */

export type TimelineEvent = {
  occurredAt: Date; recordedAt: Date | null; kind: string; title: string; detail: string | null;
  actor: string | null; ref: string | null; readPermission: string;
};

/** An entity's history from the records that mention it. occurredAt is the event; recordedAt is when LeaseOS learned of it. */
export async function loadTimeline(args: { entityType: "unit" | "job" | "trip" | "load"; entityId: number; limit?: number }): Promise<TimelineEvent[]> {
  const db = await getDb();
  if (!db) return [];
  const ev: TimelineEvent[] = [];
  const id = args.entityId;

  if (args.entityType === "unit") {
    const [defects, releases, roadside, fuel, tickets, cal] = await Promise.all([
      db.select().from(maintenanceDefects).where(eq(maintenanceDefects.unitId, id)).limit(200),
      db.select().from(workOrderReleases).where(eq(workOrderReleases.unitId, id)).limit(100),
      db.select().from(roadsideServiceEvents).where(eq(roadsideServiceEvents.unitId, id)).limit(100),
      db.select().from(fuelTransactions).where(eq(fuelTransactions.unitId, id)).limit(200),
      db.select().from(disposalTickets).where(eq(disposalTickets.unitId, id)).limit(200),
      db.select({ deviceRef: measurementDevices.deviceRef }).from(measurementDevices).limit(0),
    ]);
    void cal;
    for (const d of defects) ev.push({ occurredAt: d.reportedAt, recordedAt: d.createdAt, kind: "defect", title: `Defect reported: ${d.title}`, detail: d.detail, actor: d.reportedBy != null ? `user ${d.reportedBy}` : null, ref: `defect:${d.id}`, readPermission: "maintenance.read_defect" });
    for (const r of releases) ev.push({ occurredAt: r.releasedAt, recordedAt: r.createdAt, kind: "mechanic_release", title: `Mechanic release: ${r.releaseType}`, detail: r.repairSummary, actor: r.technicianIdentifier ?? null, ref: `release:${r.id}`, readPermission: "maintenance.read_defect" });
    for (const r of roadside) ev.push({ occurredAt: r.occurredAt, recordedAt: r.reportedAt, kind: "roadside", title: `Roadside: ${r.eventType.replace(/_/g, " ")}`, detail: r.driverStatement, actor: `user ${r.reportedByUserId}`, ref: r.eventRef, readPermission: "roadside.report" });
    for (const f of fuel) ev.push({ occurredAt: f.occurredAt, recordedAt: f.createdAt, kind: "fuel", title: `Fuel: ${f.quantity ?? "?"} ${f.quantityUnit ?? ""} ${f.fuelType}`, detail: f.vendorName, actor: f.fueledByUserId != null ? `user ${f.fueledByUserId}` : null, ref: f.fuelRef, readPermission: "tax.expense.review" });
    for (const t of tickets) ev.push({ occurredAt: t.scaleInAt ?? t.createdAt, recordedAt: t.createdAt, kind: "disposal_ticket", title: `Disposal ticket ${t.facilityTicketNumber ?? t.ticketNumber} (${t.verificationStatus})`, detail: t.netKg != null ? `${t.netKg} kg net` : null, actor: null, ref: t.ticketNumber, readPermission: "evidence.read_job_operational" });
  } else if (args.entityType === "job") {
    const [tr, ld, tk] = await Promise.all([
      db.select().from(trips).where(eq(trips.jobId, id)).limit(100),
      db.select().from(loads).where(eq(loads.jobId, id)).limit(200),
      db.select().from(disposalTickets).where(eq(disposalTickets.jobId, id)).limit(200),
    ]);
    for (const t of tr) ev.push({ occurredAt: t.startedAt ?? t.createdAt, recordedAt: t.createdAt, kind: "trip", title: `Trip ${t.tripNumber} (${t.status})`, detail: null, actor: null, ref: t.tripNumber, readPermission: "trip.read" });
    for (const l of ld) ev.push({ occurredAt: l.createdAt, recordedAt: l.createdAt, kind: "load", title: `Load ${l.loadNumber ?? l.id}: ${l.chainState}`, detail: l.material, actor: null, ref: l.loadNumber, readPermission: "load.read" });
    for (const t of tk) ev.push({ occurredAt: t.scaleInAt ?? t.createdAt, recordedAt: t.createdAt, kind: "disposal_ticket", title: `Disposal ticket ${t.facilityTicketNumber ?? t.ticketNumber} (${t.verificationStatus})`, detail: null, actor: null, ref: t.ticketNumber, readPermission: "evidence.read_job_operational" });
  } else if (args.entityType === "trip") {
    const [ld, tk, fuel] = await Promise.all([
      db.select().from(loads).where(eq(loads.tripId, id)).limit(100),
      db.select().from(disposalTickets).where(eq(disposalTickets.tripId, id)).limit(100),
      db.select().from(fuelTransactions).where(eq(fuelTransactions.tripId, id)).limit(100),
    ]);
    for (const l of ld) ev.push({ occurredAt: l.createdAt, recordedAt: l.createdAt, kind: "load", title: `Load ${l.loadNumber ?? l.id}: ${l.chainState}`, detail: l.material, actor: null, ref: l.loadNumber, readPermission: "load.read" });
    for (const t of tk) ev.push({ occurredAt: t.scaleInAt ?? t.createdAt, recordedAt: t.createdAt, kind: "disposal_ticket", title: `Disposal ticket ${t.facilityTicketNumber ?? t.ticketNumber}`, detail: null, actor: null, ref: t.ticketNumber, readPermission: "evidence.read_job_operational" });
    for (const f of fuel) ev.push({ occurredAt: f.occurredAt, recordedAt: f.createdAt, kind: "fuel", title: `Fuel: ${f.quantity ?? "?"} ${f.quantityUnit ?? ""}`, detail: f.vendorName, actor: null, ref: f.fuelRef, readPermission: "tax.expense.review" });
  } else {
    const [tk, receipts] = await Promise.all([
      db.select().from(disposalTickets).where(eq(disposalTickets.loadId, id)).limit(50),
      db.select().from(assistantCommitReceipts).where(and(eq(assistantCommitReceipts.targetType, "disposal_ticket"))).limit(0),
    ]);
    void receipts;
    for (const t of tk) ev.push({ occurredAt: t.scaleInAt ?? t.createdAt, recordedAt: t.createdAt, kind: "disposal_ticket", title: `Disposal ticket ${t.facilityTicketNumber ?? t.ticketNumber} (${t.verificationStatus})`, detail: t.netKg != null ? `${t.netKg} kg net` : null, actor: null, ref: t.ticketNumber, readPermission: "evidence.read_job_operational" });
  }
  return ev.sort((a, b) => a.occurredAt.getTime() - b.occurredAt.getTime()).slice(-(args.limit ?? 200));
}
