/**
 * Compliance Master Registry — the API.
 *
 * Requirements come from the registry (the seed until rows are loaded), never
 * from the request. A verified requirement can only be created by a
 * controller from a verified source. Private credential detail leaves HR only
 * as "eligible: yes | no | unknown". Written programs are versioned and never
 * overwritten.
 */

import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { and, desc, eq, isNull } from "drizzle-orm";
import { roleProcedure, router } from "./_core/trpc";
import { getDb } from "./db";
import { carrierProfileReviews, complianceConsents, complianceDocuments, complianceRequirements, writtenProgramVersions } from "../drizzle/schema";
import {
  abstractRequestPermitted, buildPassport, composeJobPassport, medicalFitnessForDispatch, nextRenewalDue,
  type Credential, type Passport, type Requirement, type Subject,
} from "./_core/compliancePassport";
import { COMPLIANCE_REQUIREMENT_SEEDS } from "./_core/complianceRequirementSeeds";

const ref = (p: string) => `${p}-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
const SUBJECT = z.enum(["operator", "unit", "trailer", "carrier", "job", "user"]);

async function loadRequirements(): Promise<Requirement[]> {
  const db = await getDb();
  const seeded = [...COMPLIANCE_REQUIREMENT_SEEDS];
  if (!db) return seeded;
  const rows = await db.select().from(complianceRequirements);
  const loaded: Requirement[] = rows.map(r => ({
    requirementKey: r.requirementKey, version: r.version, family: r.family, title: r.title,
    subjectType: r.subjectType, jurisdiction: r.jurisdiction,
    appliesWhen: r.appliesWhenJson ? JSON.parse(r.appliesWhenJson) : null,
    satisfiedByDocTypes: JSON.parse(r.satisfiedByDocTypes), renewalIntervalDays: r.renewalIntervalDays,
    warnDaysBeforeExpiry: r.warnDaysBeforeExpiry, missingSeverity: r.missingSeverity,
    verificationStatus: r.verificationStatus, effectiveFrom: r.effectiveFrom, effectiveUntil: r.effectiveUntil,
  }));
  // A loaded row supersedes the seed with the same key.
  const keys = new Set(loaded.map(l => l.requirementKey));
  return [...loaded, ...seeded.filter(s => !keys.has(s.requirementKey))];
}

async function loadCredentials(ownerType: string, ownerId: number): Promise<Credential[]> {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select().from(complianceDocuments).where(and(eq(complianceDocuments.ownerType, ownerType as never), eq(complianceDocuments.ownerId, ownerId)));
  return rows.map(r => ({
    docType: r.docType, requirementKey: r.requirementKey, issuedAt: r.issuedAt, expiresAt: r.expiresAt,
    verificationStatus: r.verificationStatus, privateDetail: r.privateDetail, jurisdiction: r.jurisdiction,
  }));
}

async function passportFor(subjectType: Subject["subjectType"], subjectId: number, jurisdiction: string, attributes: Record<string, unknown>): Promise<Passport> {
  const [requirements, credentials] = await Promise.all([loadRequirements(), loadCredentials(subjectType, subjectId)]);
  return buildPassport({ subject: { subjectType, jurisdiction, attributes }, requirements, credentials, now: new Date() });
}

export const complianceRouter = router({
  passport: roleProcedure("compliance.passport")
    .input(z.object({ subjectType: SUBJECT, subjectId: z.number().int().positive(), jurisdiction: z.string().min(2).max(80), attributes: z.record(z.string(), z.unknown()).default({}) }))
    .query(async ({ input }) => {
      const p = await passportFor(input.subjectType, input.subjectId, input.jurisdiction, input.attributes);
      // Private detail never rides out on a passport. Items are requirement
      // level; the credential row is not included.
      return p;
    }),

  jobPassport: roleProcedure("compliance.jobPassport")
    .input(z.object({
      jurisdiction: z.string().min(2).max(80),
      carrier: z.object({ id: z.number().int().positive(), attributes: z.record(z.string(), z.unknown()).default({}) }).nullable(),
      operator: z.object({ id: z.number().int().positive(), attributes: z.record(z.string(), z.unknown()).default({}) }).nullable(),
      unit: z.object({ id: z.number().int().positive(), attributes: z.record(z.string(), z.unknown()).default({}) }).nullable(),
      trailer: z.object({ id: z.number().int().positive(), attributes: z.record(z.string(), z.unknown()).default({}) }).nullable().optional(),
    }))
    .query(async ({ input }) => {
      const parts: Record<string, Passport | null> = {
        carrier: input.carrier ? await passportFor("carrier", input.carrier.id, input.jurisdiction, input.carrier.attributes) : null,
        operator: input.operator ? await passportFor("operator", input.operator.id, input.jurisdiction, input.operator.attributes) : null,
        unit: input.unit ? await passportFor("unit", input.unit.id, input.jurisdiction, input.unit.attributes) : null,
      };
      if (input.trailer !== undefined) parts.trailer = input.trailer ? await passportFor("trailer", input.trailer.id, input.jurisdiction, input.trailer.attributes) : null;
      return composeJobPassport(parts);
    }),

  /** The only shape medical fitness takes outside HR. */
  medicalEligibility: roleProcedure("compliance.medicalEligibility")
    .input(z.object({ operatorId: z.number().int().positive() }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return { eligible: "unknown" as const, reviewDue: null };
      const rows = await db.select().from(complianceDocuments)
        .where(and(eq(complianceDocuments.ownerType, "operator"), eq(complianceDocuments.ownerId, input.operatorId), eq(complianceDocuments.docType, "medical_fitness")))
        .orderBy(desc(complianceDocuments.expiresAt)).limit(1);
      const r = rows[0];
      return medicalFitnessForDispatch(r ? { docType: r.docType, expiresAt: r.expiresAt, verificationStatus: r.verificationStatus, privateDetail: r.privateDetail } : null, new Date());
    }),

  credentialRecord: roleProcedure("compliance.credentialRecord")
    .input(z.object({
      ownerType: z.enum(["operator", "unit", "job", "trailer", "carrier", "user", "equipment"]), ownerId: z.number().int().positive(),
      docType: z.string().min(2).max(100), requirementKey: z.string().max(120).nullable().optional(),
      title: z.string().min(1).max(220), identifier: z.string().max(120).nullable().optional(),
      issuedAt: z.coerce.date().nullable().optional(), expiresAt: z.coerce.date().nullable().optional(),
      jurisdiction: z.string().max(80).nullable().optional(), source: z.string().max(220).nullable().optional(),
      privateDetail: z.boolean().default(false), evidenceRecordId: z.number().int().positive().nullable().optional(),
    }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
      // Recorded is not verified. Every credential enters as needs_review.
      const ins = await db.insert(complianceDocuments).values({
        ownerType: input.ownerType, ownerId: input.ownerId, docType: input.docType, requirementKey: input.requirementKey ?? null,
        title: input.title, identifier: input.identifier ?? null, capturedAt: new Date(), issuedAt: input.issuedAt ?? null,
        expiresAt: input.expiresAt ?? null, jurisdiction: input.jurisdiction ?? null, verificationStatus: "needs_review",
        source: input.source ?? null, confidence: "medium", privateDetail: input.privateDetail || input.docType === "medical_fitness",
        evidenceRecordId: input.evidenceRecordId ?? null,
      });
      return { credentialId: Number(ins[0]?.insertId ?? 0), verificationStatus: "needs_review" as const };
    }),

  credentialVerify: roleProcedure("compliance.credentialVerify")
    .input(z.object({ credentialId: z.number().int().positive(), outcome: z.enum(["verified", "rejected"]), note: z.string().max(400).optional() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
      const rows = await db.select().from(complianceDocuments).where(eq(complianceDocuments.id, input.credentialId)).limit(1);
      if (!rows[0]) throw new TRPCError({ code: "NOT_FOUND", message: "Credential not found" });
      await db.update(complianceDocuments).set({ verificationStatus: input.outcome, verifiedByUserId: ctx.user.id, verifiedAt: new Date() }).where(eq(complianceDocuments.id, input.credentialId));
      return { credentialId: input.credentialId, verificationStatus: input.outcome };
    }),

  consentRecord: roleProcedure("compliance.consentRecord")
    .input(z.object({
      subjectUserId: z.number().int().positive(),
      consentType: z.enum(["driver_abstract", "commercial_driver_abstract", "medical_fitness_confirmation", "experience_record_release", "background_check", "other"]),
      purpose: z.string().min(3).max(300), signedAt: z.coerce.date(), validUntil: z.coerce.date().nullable().optional(),
      signatureEvidenceRecordId: z.number().int().positive().nullable().optional(), payloadHash: z.string().regex(/^[a-f0-9]{64}$/).nullable().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
      const consentRef = ref("CONSENT");
      await db.insert(complianceConsents).values({
        consentRef, subjectUserId: input.subjectUserId, consentType: input.consentType, purpose: input.purpose,
        requestedByUserId: ctx.user.id, signedAt: input.signedAt, validUntil: input.validUntil ?? null,
        signatureEvidenceRecordId: input.signatureEvidenceRecordId ?? null, payloadHash: input.payloadHash ?? null,
      });
      const permitted = abstractRequestPermitted({ consent: { signedAt: input.signedAt, validUntil: input.validUntil ?? null, consentType: input.consentType }, now: new Date() });
      return { consentRef, abstractRequestPermitted: permitted.permitted };
    }),

  /**
   * Load or verify a requirement. Controller-only and sensitive, for the same
   * reason as tax rules: this is the act that lets a passport say READY. An
   * unverified source cannot produce a verified requirement.
   */
  requirementLoad: roleProcedure("compliance.requirementLoad")
    .input(z.object({
      requirementKey: z.string().min(3).max(120), family: z.string().min(2).max(60), title: z.string().min(3).max(220),
      subjectType: SUBJECT, jurisdiction: z.string().min(1).max(80), appliesWhen: z.record(z.string(), z.unknown()).nullable().optional(),
      satisfiedByDocTypes: z.array(z.string().min(1)).min(1), renewalIntervalDays: z.number().int().positive().nullable().optional(),
      warnDaysBeforeExpiry: z.number().int().nonnegative().default(30), missingSeverity: z.enum(["review", "blocked"]).default("review"),
      sourceAuthority: z.string().max(220).nullable().optional(), sourceUrl: z.string().max(600).nullable().optional(), sourceReference: z.string().max(300).nullable().optional(),
      sourceVerified: z.boolean().default(false), requestedStatus: z.enum(["unverified", "verified"]).default("unverified"), effectiveFrom: z.coerce.date(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
      const stored = input.requestedStatus === "verified" && input.sourceVerified && input.sourceAuthority?.trim() ? "verified" : "unverified";
      const prior = await db.select({ version: complianceRequirements.version }).from(complianceRequirements).where(eq(complianceRequirements.requirementKey, input.requirementKey)).orderBy(desc(complianceRequirements.version)).limit(1);
      const version = (prior[0]?.version ?? 0) + 1;
      if (prior[0]) {
        // The previous version is superseded, not overwritten.
        await db.update(complianceRequirements).set({ verificationStatus: "superseded", effectiveUntil: input.effectiveFrom })
          .where(and(eq(complianceRequirements.requirementKey, input.requirementKey), eq(complianceRequirements.version, prior[0].version)));
      }
      await db.insert(complianceRequirements).values({
        requirementKey: input.requirementKey, version, family: input.family, title: input.title, subjectType: input.subjectType, jurisdiction: input.jurisdiction,
        appliesWhenJson: input.appliesWhen ? JSON.stringify(input.appliesWhen) : null, satisfiedByDocTypes: JSON.stringify(input.satisfiedByDocTypes),
        renewalIntervalDays: input.renewalIntervalDays ?? null, warnDaysBeforeExpiry: input.warnDaysBeforeExpiry, missingSeverity: input.missingSeverity,
        sourceAuthority: input.sourceAuthority ?? null, sourceUrl: input.sourceUrl ?? null, sourceReference: input.sourceReference ?? null,
        effectiveFrom: input.effectiveFrom, verificationStatus: stored, verifiedByUserId: stored === "verified" ? ctx.user.id : null, verifiedAt: stored === "verified" ? new Date() : null,
      });
      return { requirementKey: input.requirementKey, version, storedStatus: stored, note: stored === "unverified" && input.requestedStatus === "verified" ? "Stored unverified: a requirement cannot be verified unless its source is verified and names an authority" : undefined };
    }),

  programPublish: roleProcedure("compliance.programPublish")
    .input(z.object({
      programKey: z.string().min(2).max(80), title: z.string().min(3).max(220), programType: z.enum(["safety", "maintenance", "ohs", "emergency_response", "other"]),
      financialEntityId: z.number().int().positive(), effectiveFrom: z.coerce.date(), reviewDueAt: z.coerce.date().nullable().optional(),
      documentEvidenceRecordId: z.number().int().positive().nullable().optional(), contentHash: z.string().regex(/^[a-f0-9]{64}$/).nullable().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
      const prior = await db.select({ id: writtenProgramVersions.id, version: writtenProgramVersions.version }).from(writtenProgramVersions)
        .where(and(eq(writtenProgramVersions.programKey, input.programKey), isNull(writtenProgramVersions.supersededAt))).orderBy(desc(writtenProgramVersions.version)).limit(1);
      const version = (prior[0]?.version ?? 0) + 1;
      const now = new Date();
      await db.insert(writtenProgramVersions).values({
        programKey: input.programKey, version, title: input.title, programType: input.programType, financialEntityId: input.financialEntityId,
        effectiveFrom: input.effectiveFrom, approvedByUserId: ctx.user.id, approvedAt: now, reviewDueAt: input.reviewDueAt ?? null,
        documentEvidenceRecordId: input.documentEvidenceRecordId ?? null, contentHash: input.contentHash ?? null,
      });
      if (prior[0]) {
        // Previous version stays; it is marked superseded, with a pointer forward.
        await db.update(writtenProgramVersions).set({ supersededAt: now, supersededByVersion: version }).where(eq(writtenProgramVersions.id, prior[0].id));
      }
      return { programKey: input.programKey, version, supersededVersion: prior[0]?.version ?? null };
    }),

  profileReviewRecord: roleProcedure("compliance.profileReviewRecord")
    .input(z.object({
      financialEntityId: z.number().int().positive(), jurisdiction: z.string().min(2).max(80), profileObtainedAt: z.coerce.date(),
      inspectionsOnProfile: z.number().int().nonnegative(), convictionsOnProfile: z.number().int().nonnegative(), collisionsOnProfile: z.number().int().nonnegative(),
      knownInspections: z.number().int().nonnegative(), knownConvictions: z.number().int().nonnegative(), knownCollisions: z.number().int().nonnegative(),
      riskTrend: z.enum(["improving", "stable", "worsening", "unknown"]).default("unknown"), evidenceRecordId: z.number().int().positive().nullable().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable" });
      // Anything on the regulator's profile that LeaseOS does not know about is
      // an exception to investigate, not a number to file.
      const unmatched = Math.max(0, input.inspectionsOnProfile - input.knownInspections) + Math.max(0, input.convictionsOnProfile - input.knownConvictions) + Math.max(0, input.collisionsOnProfile - input.knownCollisions);
      const reviewRef = ref("CPR");
      const next = nextRenewalDue({ lastObtainedAt: input.profileObtainedAt, intervalDays: 91 });
      await db.insert(carrierProfileReviews).values({
        reviewRef, financialEntityId: input.financialEntityId, jurisdiction: input.jurisdiction, profileObtainedAt: input.profileObtainedAt,
        reviewedAt: new Date(), reviewedByUserId: ctx.user.id, nextReviewDueAt: next.dueAt,
        inspectionsOnProfile: input.inspectionsOnProfile, convictionsOnProfile: input.convictionsOnProfile, collisionsOnProfile: input.collisionsOnProfile,
        unmatchedExternalEvents: unmatched, riskTrend: input.riskTrend, evidenceRecordId: input.evidenceRecordId ?? null,
      });
      return { reviewRef, unmatchedExternalEvents: unmatched, nextReviewDueAt: next.dueAt, exception: unmatched > 0 ? `${unmatched} external compliance event(s) unmatched — investigate` : null };
    }),
});
